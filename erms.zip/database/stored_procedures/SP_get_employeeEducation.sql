CREATE procedure SP_get_employeeEducation
    
AS
BEGIN
    SELECT * from EMPLOYEE_EDUCATION ;

END
