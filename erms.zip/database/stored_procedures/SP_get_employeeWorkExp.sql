CREATE procedure SP_get_employeeWorkExperience
    
AS
BEGIN
    SELECT * from EMPLOYEE_WORK_EXPERIENCE;

END