CREATE procedure SP_get_employeeAddress
    
AS
BEGIN
    SELECT * from EMPLOYEE_ADDRESS;
    
END